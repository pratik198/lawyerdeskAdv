import React from "react";
import "./TopNavBar.css";
import { FaSearch, FaUserCircle, FaCog } from "react-icons/fa";

const TopNavBar = () => {
  return (
    <div className="top-nav-bar">
      <div className="logo">
        ADVOC<em>ASE</em>
      </div>
      <div className="nav-links">
        <a href="#news-feed">News Feed</a>
        <a href="#find-lawyers">Find Lawyers</a>
        <a href="#home">Home</a>
        <a href="#connections">Connections</a>
        <a href="#chats">Chats</a>
      </div>
      <div className="nav-icons">
        <FaSearch className="icon search-icon" />
        <FaCog className="icon settings-icon" />
        <FaUserCircle className="icon user-icon" />
      </div>
    </div>
  );
};

export default TopNavBar;
